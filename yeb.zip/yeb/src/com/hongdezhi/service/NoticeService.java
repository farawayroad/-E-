package com.hongdezhi.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.hongdezhi.dao.NoticeDao;
import com.hongdezhi.domain.Notice;
import com.hongdezhi.utils.C3P0Utils;

public class NoticeService {
	NoticeDao noticedao = new NoticeDao();
	
	// 添加公告的操作 insert
			public boolean insert(Notice notice){	
				try {
					return noticedao.insert(notice);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new RuntimeException(e);
				}
			}
			// 查询所有的Notice对象 query
			public List<Notice> findAll() {
				try {
					return noticedao.findAll();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new RuntimeException(e);
				}
			}
			// 根据id查找指定的Notice query 模糊查询
			public Notice find(int id){
				try {
					return noticedao.find(id);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new RuntimeException(e);
				}
			}
			
			// 根据TITLE查找指定的Notice query 模糊查询
			public List findT(String title){
				try {
					return noticedao.findT(title);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new RuntimeException(e);
				}
			}
			
			// 根据CONTENT查找指定的Notice query 模糊查询
			public List findC(String title) {
				try {
					return noticedao.findC(title);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new RuntimeException(e);
				}
				
			}
			
			// 根据CREATE_DATE查找指定的Notice query 模糊查询
			public List findD(String title) {
					try {
						return noticedao.findD(title);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						throw new RuntimeException(e);
					}
			}
			
			// 根据USER_ID查找指定的Notice query 模糊查询
			public List findU(String title){
				try {
					return noticedao.findU(title);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new RuntimeException(e);
				}
				
			}
			
			// 删除用户 update
			public boolean delete(int id){
				try {
					return noticedao.delete(id);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new RuntimeException(e);
				}
				
			}
			// 修改用户 update
			public boolean update(Notice notice){
				try {
					return noticedao.update(notice);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new RuntimeException(e);
				}
				
				
			}
}
