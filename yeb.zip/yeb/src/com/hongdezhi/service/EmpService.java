package com.hongdezhi.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.hongdezhi.dao.EmployeesDao;
import com.hongdezhi.domain.Employee;
import com.hongdezhi.domain.Notice;
import com.hongdezhi.utils.C3P0Utils;

public class EmpService {
	EmployeesDao emydao = new EmployeesDao();

	public boolean insert(Employee emp) {

		try {
			return emydao.insert(emp);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public List<Employee> findAll() {
		try {
			return emydao.findAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}

	public Employee find(String name) {
		try {
			return emydao.find(name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}

	}

	public String login(String nameid, String password) {
		try {
			return emydao.login(nameid, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}

	}

	// 删除用户 update
	public boolean delete(int id) {
		try {
			return emydao.delete(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}

	}

	// 修改数据 update 修改查询到的数据
	public boolean update(Employee emp) {
		try {
			return emydao.update(emp);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}
}
