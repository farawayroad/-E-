package com.hongdezhi.domain;


public class Notice {
	public Integer id;
	public String title;
	public String content;
	public String createdate;
	public Integer userid;
	public Notice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Notice(Integer id, String title, String content, String createdate, Integer userid) {
		super();
		this.id = id;
		this.title = title;
		this.content = content;
		this.createdate = createdate;
		this.userid = userid;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCreatedate() {
		return createdate;
	}
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	@Override
	public String toString() {
		return "Notice [id=" + id + ", title=" + title + ", content=" + content + ", createdate=" + createdate
				+ ", userid=" + userid + "]";
	}
	
	
}
