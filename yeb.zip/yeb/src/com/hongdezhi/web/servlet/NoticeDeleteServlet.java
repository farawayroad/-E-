package com.hongdezhi.web.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hongdezhi.service.NoticeService;


/**
 * Servlet implementation class NoticeDeleteServlet
 */
public class NoticeDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean f = false;
		String sid = request.getParameter("id");
		if (sid != null && !sid.isEmpty()) {
			int id = Integer.parseInt(sid);
			f = new NoticeService().delete(id);
		}
		if (f) {
			request.setAttribute("remsg", "alert('删除成功')");
			request.getRequestDispatcher("/ntList.jsp").forward(request, response);
		} else {
			request.setAttribute("remsg", "alert('删除失败')");
			request.getRequestDispatcher("/ntList.jsp").forward(request, response);
		}
//		response.setHeader("refresh", "1;url=/hrm/ntList.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
