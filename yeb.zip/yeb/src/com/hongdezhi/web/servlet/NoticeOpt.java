package com.hongdezhi.web.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;


import com.hongdezhi.domain.Notice;
import com.hongdezhi.service.NoticeService;



/**
 * Servlet implementation class NoticeOpt
 */
public class NoticeOpt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO 对数据库进行操作
				Notice notice=new Notice();
				String title = request.getParameter("title");
				String content = request.getParameter("content");
				notice.setTitle(title);
				notice.setContent(content);
				
				
				if(new NoticeService().insert(notice)){
					request.setAttribute("msg", "alert('添加成功')");
					System.out.println("添加成功");
					request.getRequestDispatcher("/ntList.jsp").forward(request, response);
				}else{
					request.setAttribute("msg", "alert('添加失败')");
					request.getRequestDispatcher("/ntAdd.jsp").forward(request, response);
				}
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	

}
