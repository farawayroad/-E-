/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50724
Source Host           : localhost:3306
Source Database       : oam3

Target Server Type    : MYSQL
Target Server Version : 50724
File Encoding         : 65001

Date: 2020-11-17 18:34:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dept_inf
-- ----------------------------
DROP TABLE IF EXISTS `dept_inf`;
CREATE TABLE `dept_inf` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id号',
  `name` varchar(50) NOT NULL COMMENT '职位名',
  `remark` varchar(300) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of dept_inf
-- ----------------------------
INSERT INTO `dept_inf` VALUES ('1', '技术部', '技术部');
INSERT INTO `dept_inf` VALUES ('2', '运营部', '运营部');
INSERT INTO `dept_inf` VALUES ('3', '财务部', '财务部');
INSERT INTO `dept_inf` VALUES ('5', '总公办', '总公办');
INSERT INTO `dept_inf` VALUES ('6', '市场部', '市场部');
INSERT INTO `dept_inf` VALUES ('7', '教学部', '教学部');
INSERT INTO `dept_inf` VALUES ('8', '测试部', '测试部');
INSERT INTO `dept_inf` VALUES ('9', '营销部', '营销部');
INSERT INTO `dept_inf` VALUES ('10', '通讯部', '通讯部');
INSERT INTO `dept_inf` VALUES ('11', '生产技术部', '生产技术的部们');
INSERT INTO `dept_inf` VALUES ('12', '监察部', '监察部');
INSERT INTO `dept_inf` VALUES ('13', '生产部', '生产部');
INSERT INTO `dept_inf` VALUES ('14', '经营部', '经营部');
INSERT INTO `dept_inf` VALUES ('15', '管理部', '管理部');
INSERT INTO `dept_inf` VALUES ('16', '服务部', '服务部');
INSERT INTO `dept_inf` VALUES ('18', '工商税务部', '工商税务部');
INSERT INTO `dept_inf` VALUES ('19', '工商部', '工商部');
INSERT INTO `dept_inf` VALUES ('20', '制度部', '制度部');
INSERT INTO `dept_inf` VALUES ('21', '协调部', '协调部');
INSERT INTO `dept_inf` VALUES ('22', '人事部', '人事部');
INSERT INTO `dept_inf` VALUES ('23', '培训部', '培训部');
INSERT INTO `dept_inf` VALUES ('24', '劳资部', '劳资部');
INSERT INTO `dept_inf` VALUES ('25', '考勤部', '考勤部');
INSERT INTO `dept_inf` VALUES ('26', '保险部', '保险部');
INSERT INTO `dept_inf` VALUES ('27', '职称部', '职称部');
INSERT INTO `dept_inf` VALUES ('28', '收支部', '收支部');
INSERT INTO `dept_inf` VALUES ('29', '决算部', '决算部');
INSERT INTO `dept_inf` VALUES ('30', '革新部', '革新部');
INSERT INTO `dept_inf` VALUES ('31', '维护部', '维护部');
INSERT INTO `dept_inf` VALUES ('32', '市场营销部', '市场营销部');
INSERT INTO `dept_inf` VALUES ('33', '客户服务部', '客户服务部');
INSERT INTO `dept_inf` VALUES ('34', '营销部', '营销部');
INSERT INTO `dept_inf` VALUES ('35', '安全监察部', '安全监察部');
INSERT INTO `dept_inf` VALUES ('36', '党群工作部', '党群工作部');
INSERT INTO `dept_inf` VALUES ('37', '党委办公室', '党委办公室');
INSERT INTO `dept_inf` VALUES ('38', '组织部', '组织部');
INSERT INTO `dept_inf` VALUES ('39', '宣传部', '宣传部');
INSERT INTO `dept_inf` VALUES ('40', '纪检监察部', '纪检监察部');
INSERT INTO `dept_inf` VALUES ('41', '工会办公室', '工会办公室');
INSERT INTO `dept_inf` VALUES ('42', '保卫部', '保卫部');
INSERT INTO `dept_inf` VALUES ('43', '后勤部', '后勤部');
INSERT INTO `dept_inf` VALUES ('44', '订单部', '订单部');
INSERT INTO `dept_inf` VALUES ('45', '需求部', '需求部');
INSERT INTO `dept_inf` VALUES ('46', '档案部', '档案部');
INSERT INTO `dept_inf` VALUES ('47', '系统部', '系统部');
INSERT INTO `dept_inf` VALUES ('48', '决策部', '决策部');
INSERT INTO `dept_inf` VALUES ('49', '人力资源部', '人力资源部');
INSERT INTO `dept_inf` VALUES ('50', '税务部', '税务部');
INSERT INTO `dept_inf` VALUES ('52', '监察部', '监察部');
INSERT INTO `dept_inf` VALUES ('53', '生产部', '生产部');
INSERT INTO `dept_inf` VALUES ('54', '经营部', '经营部');
INSERT INTO `dept_inf` VALUES ('55', '管理部', '管理部');
INSERT INTO `dept_inf` VALUES ('56', '服务部', '服务部');
INSERT INTO `dept_inf` VALUES ('58', '工商税务部', '工商税务部');
INSERT INTO `dept_inf` VALUES ('59', '工商部', '工商部');
INSERT INTO `dept_inf` VALUES ('60', '制度部', '制度部');
INSERT INTO `dept_inf` VALUES ('62', '人事部', '人事部');
INSERT INTO `dept_inf` VALUES ('63', '培训部', '培训部');
INSERT INTO `dept_inf` VALUES ('64', '劳资部', '劳资部');
INSERT INTO `dept_inf` VALUES ('65', '考勤部', '考勤部');
INSERT INTO `dept_inf` VALUES ('66', '保险部', '保险部');
INSERT INTO `dept_inf` VALUES ('67', '职称部', '职称部');
INSERT INTO `dept_inf` VALUES ('68', '收支部', '收支部');
INSERT INTO `dept_inf` VALUES ('69', '决算部', '决算部');
INSERT INTO `dept_inf` VALUES ('70', '革新部', '革新部');
INSERT INTO `dept_inf` VALUES ('71', '维护部', '维护部');
INSERT INTO `dept_inf` VALUES ('72', '市场营销部', '市场营销部');
INSERT INTO `dept_inf` VALUES ('73', '客户服务部', '客户服务部');
INSERT INTO `dept_inf` VALUES ('74', '营销部', '营销部');
INSERT INTO `dept_inf` VALUES ('75', '安全监察部', '安全监察部');
INSERT INTO `dept_inf` VALUES ('76', '党群工作部', '党群工作部');
INSERT INTO `dept_inf` VALUES ('77', '党委办公室', '党委办公室');
INSERT INTO `dept_inf` VALUES ('78', '组织部', '组织部');
INSERT INTO `dept_inf` VALUES ('79', '宣传部', '宣传部');
INSERT INTO `dept_inf` VALUES ('80', '纪检监察部', '纪检监察部');
INSERT INTO `dept_inf` VALUES ('81', '工会办公室', '工会办公室');
INSERT INTO `dept_inf` VALUES ('82', '保卫部', '保卫部');
INSERT INTO `dept_inf` VALUES ('83', '后勤部', '后勤部');
INSERT INTO `dept_inf` VALUES ('84', '订单部', '订单部');
INSERT INTO `dept_inf` VALUES ('85', '需求部', '需求部');
INSERT INTO `dept_inf` VALUES ('86', '档案部', '档案部');
INSERT INTO `dept_inf` VALUES ('87', '系统部', '系统部');
INSERT INTO `dept_inf` VALUES ('89', '技术部', '技术部');
INSERT INTO `dept_inf` VALUES ('90', '', '');
INSERT INTO `dept_inf` VALUES ('91', 'Appolo', '??');

-- ----------------------------
-- Table structure for employee_inf
-- ----------------------------
DROP TABLE IF EXISTS `employee_inf`;
CREATE TABLE `employee_inf` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id号',
  `dept_id` int(11) NOT NULL COMMENT '所在部门id',
  `job_id` int(11) NOT NULL COMMENT '所在职位id',
  `name` varchar(20) NOT NULL COMMENT '员工名',
  `card_id` varchar(18) NOT NULL COMMENT '身份证号',
  `address` varchar(50) NOT NULL COMMENT '所在地址',
  `post_code` varchar(50) DEFAULT NULL COMMENT '所在地址邮箱编码',
  `tel` varchar(16) DEFAULT NULL COMMENT '座机号码',
  `phone` varchar(11) NOT NULL COMMENT '移动号码',
  `qq_num` varchar(10) DEFAULT NULL COMMENT 'QQ号',
  `email` varchar(50) NOT NULL COMMENT '邮箱号',
  `sex` int(11) NOT NULL DEFAULT '1' COMMENT '性别',
  `party` varchar(10) DEFAULT NULL COMMENT 'part地点',
  `birthday` datetime DEFAULT NULL COMMENT '生日',
  `race` varchar(100) DEFAULT NULL COMMENT '种族',
  `education` varchar(10) DEFAULT NULL COMMENT '最高学历',
  `speciality` varchar(20) DEFAULT NULL COMMENT '专业',
  `hobby` varchar(100) DEFAULT NULL COMMENT '爱好',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建日期',
  `password` varchar(16) NOT NULL COMMENT '密码',
  `nameid` varchar(29) NOT NULL COMMENT '工位号',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_EMP_DEPT` (`dept_id`) USING BTREE,
  KEY `FK_EMP_JOB` (`job_id`) USING BTREE,
  CONSTRAINT `FK_EMP_DEPT` FOREIGN KEY (`dept_id`) REFERENCES `dept_inf` (`id`),
  CONSTRAINT `FK_EMP_JOB` FOREIGN KEY (`job_id`) REFERENCES `job_inf` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=618 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of employee_inf
-- ----------------------------
INSERT INTO `employee_inf` VALUES ('1', '2', '8', '爱丽丝', '4328011988', '广州天河', '510000', '020-77777777', '13902001111', '36750066', '251425887@qq.com', '1', '党员', '2020-06-15 00:00:00', '满', '本科', '美声', '唱歌', '1', '2020-06-18 11:44:34', '123456', '');
INSERT INTO `employee_inf` VALUES ('4', '3', '7', '张杰', '24516354812', '四川', '241525', '020-14562154', '18315624516', '3521086425', '3521086425@qq.com', '1', null, '1889-05-12 12:30:00', '汉', '本科', '美声', '唱歌', null, '2019-05-06 11:20:12', '123456', '');
INSERT INTO `employee_inf` VALUES ('5', '5', '5', '王一博', '500240200000562164', '河南', '516455', '151155151511', '11212145665', '1254541145', '1254541145@qq.com', '1', '党员', '1997-08-15 00:00:00', '汉', '本科', '表演', '滑板', '1', '2020-06-18 09:28:29', '123456', '');
INSERT INTO `employee_inf` VALUES ('6', '6', '6', '肖战', '154631465614656132', '重庆', '112121', '001232012133', '10021320241', '1214632158', '1214632158@qq.com', '1', null, null, null, null, null, null, null, '2020-06-16 19:23:19', '123456', '');
INSERT INTO `employee_inf` VALUES ('7', '7', '7', '许飞', '146461212158365665', '河北', '656656', '215623165623', '16530146563', '1216563363', '1216563363@qq.com', '1', null, null, null, null, null, null, null, '2020-06-16 19:25:12', '123456', '');
INSERT INTO `employee_inf` VALUES ('8', '5', '8', '宁静', '254632465666563366', '黑龙江', '163235', '321454512123', '15121231233', '1036623331', '1036623331@qq.com', '1', null, null, null, null, null, null, null, '2020-06-16 19:27:08', '123456', '');
INSERT INTO `employee_inf` VALUES ('9', '6', '7', '许凯', '135632131363656463', '武汉', '154646', '656562316646', '63654623215', '1546523153', '1546523153@qq.com', '1', null, null, null, null, null, null, null, '2020-06-16 20:07:58', '123456', '');
INSERT INTO `employee_inf` VALUES ('10', '2', '3', '张艺兴', '153102125453131256', '山东', '154512', '121564623113', '12156460231', '4411214666', '4411214666@qq.com', '1', null, null, null, null, null, null, null, '2020-06-16 20:09:26', '123456', '');
INSERT INTO `employee_inf` VALUES ('582', '5', '4', '瑞杰', '511186421728', '重庆', '513100', '131-5488172', '1618267824', '7568251', '7568251qq.com', '1', '党员', '2000-05-11 00:00:00', '汉', '本科', '下棋', '打游戏', '2', '2019-03-16 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('583', '7', '2', '莺语', '411173800091', '四川', '762210', '121-3988812', '1888888888', '3364888', '33648882@qq.com', '0', '党员', '2000-03-26 00:00:00', '汉', '本科', '购物', '直播', '2', '2019-03-16 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('584', '6', '3', '周杰', '411347627681', '黑龙江', '739968', '101-84111902', '1875631817', '3584617', '3584617@qq.com', '1', '党员', '2001-02-11 00:00:00', '汉', '本科', '弹琴', '唱歌', '1', '2019-02-12 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('585', '8', '3', '李公明', '411173700091', '辽宁', '7631210', '121-3988812', '1882221234', '7622101', '7622101@qq.com', '0', '党员', '1999-12-26 00:00:00', '白', '本科', '下棋', '喝茶', '2', '2019-04-01 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('586', '9', '5', ' 刘继兴', '411173700092', '河北', '762287', '121-3435312', '1854362788', '5100001', '5100001@qq.com', '0', '党员', '2000-07-05 00:00:00', '汉', '本科', '健身', '游泳', '1', '2019-03-17 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('587', '3', '9', '李轶男', '41115340091', '吉林', '722546', '143-6684211', '1452854960', '7225464', '7225464@qq.com', '0', '党员', '2000-05-06 00:00:00', '汉', '本科', '潜水', '登山', '2', '2019-03-18 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('588', '1', '4', '李建荣', '411233435001', '山西', '962321', '121-3446746', '1556257623', '7399681', '7399681@qq.com', '0', '党员', '1999-07-27 00:00:00', '汉', '研究生', '油画', '下棋', '1', '2019-03-18 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('589', '8', '1', '刘墉', '411576666966', '江苏', '765461', '121-3988812', '1456451212', '6745121', '6745121@qq.com', '1', '党员', '1988-08-03 00:00:00', '汉', '博士生', '登山', '做饭', '2', '2020-06-18 11:25:14', '123456', '');
INSERT INTO `employee_inf` VALUES ('590', '6', '2', '渴非', '4153656576561', '浙江', '354271', '143-3967542', '1884567861', '3665347', '3665347@qq.com', '0', '党员', '2000-06-21 00:00:00', '汉', '本科', '购物', '写字', '2', '2019-03-16 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('591', '1', '7', '胡志平', '41117388761280', '安徽', '762211', '162-3777831', '1884434526', '8111202', '8111202@qq.com', '0', '党员', '2000-04-12 00:00:00', '汉', '本科', '打篮球', '运动', '1', '2019-03-21 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('592', '3', '3', '江晓原', '4111687543456', '福建', '880210', '151-9862314', '1843544188', '7225463', '7225463@qq.com', '0', '党员', '2000-08-21 00:00:00', '藏', '研究生', '打羽毛球', '做饭', '1', '2019-03-22 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('594', '2', '1', '韩云波', '4111738767965', '山东', '366534', '132-4564543', '1886615422', '5131008', '5131008@qq.com', '0', '党员', '1999-05-20 00:00:00', '汉', '硕士生', '购物', '主播', '2', '2019-03-11 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('595', '5', '8', '何亚娟', '41117387121130', '河南', '811923', '122-9998707', '1886674432', '4597386', '4597386@qq.com', '0', '党员', '1999-01-02 00:00:00', '汉', '硕士生', '运动', '登山', '2', '2019-03-12 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('601', '8', '7', '恭小兵', '4111738345641', '贵州', '333187', '131-9674631', '1884167865', '2167818', '2167818@qq.com', '0', '党员', '2002-03-21 00:00:00', '汉', '研究生', '做饭', '油画', '1', '2019-02-27 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('602', '2', '6', '冯唐', '411173891161', '云南', '444343', '151-0012231', '1883839123', '1218901', '1218901@qq.com', '0', '党员', '2000-05-18 00:00:00', '汉', '本科', '登山', '弹琴', '2', '2019-02-28 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('611', '2', '3', '蔡伟', '411173888210', '天津', '342454', '121-1178779', '18899807790', '7647640', '7647640@qq.com', '0', '党员', '2000-09-21 00:00:00', '汉', '研究生', '做饭', '打乒乓球', '1', '2019-03-03 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('612', '5', '3', '陈远 ', '411173853218', '新疆', '121890', '121-9966847', '18877916680', '4443431', '4443431@qq.com', '0', '党员', '2000-10-10 00:00:00', '汉', '本科', '潜水', '写字', '2', '2019-03-06 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('613', '5', '1', '陈丹青', '411173863429', '宁夏', '216781', '121-4458933', '18855699931', '3331872', '3331872@qq.com', '0', '党员', '2000-06-06 00:00:00', '汉', '硕士生', '睡觉', '主播', '1', '2019-03-07 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('614', '6', '6', '程鹤麟', '411173873453', '西藏', '316859', '121-9996454', '18845532321', '8111203', '8111203@qq.com', '0', '党员', '2000-02-11 00:00:00', '汉', '本科', '做饭', '蹦极', '2', '2019-03-12 00:00:00', '123456', '');
INSERT INTO `employee_inf` VALUES ('615', '1', '1', '曹天予 ', '411173243741', '澳门', '619055', '121-5564222', '18845613428', '6745124', '6745124@qq.com', '0', '党员', '2000-11-11 00:00:00', '汉', '本科', '下棋', '油画', '2', '2019-03-10 00:00:00', '123456', '0411180306');
INSERT INTO `employee_inf` VALUES ('616', '6', '2', '而国色入干涉', '444336666', '胜多负少东方闪电', '33333', '333333', '3333333', '233333', '18333@emp.com', '1', '电饭锅电饭锅', '2020-06-23 00:00:00', '发发发', '第三方士大夫', '递四方速递', '的防守打法', '1', '2020-06-18 10:28:38', '123456', '');
INSERT INTO `employee_inf` VALUES ('617', '1', '3', '洪得智', '0411180305', '重庆', '123423', '1521234234', '1883242532', '235323', '324523@qq.com', '1', '党员', '2020-12-12 00:00:00', '汉', '本科', '下棋', '等', '1', '2020-06-19 16:41:55', '123456', '0411180305');

-- ----------------------------
-- Table structure for job_inf
-- ----------------------------
DROP TABLE IF EXISTS `job_inf`;
CREATE TABLE `job_inf` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id号',
  `name` varchar(50) NOT NULL COMMENT '职位名称',
  `remark` varchar(300) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of job_inf
-- ----------------------------
INSERT INTO `job_inf` VALUES ('1', '职员', '职员');
INSERT INTO `job_inf` VALUES ('2', 'Java开发工程师', 'Java开发工程师');
INSERT INTO `job_inf` VALUES ('3', 'Java中级开发工程师', 'Java中级开发工程师');
INSERT INTO `job_inf` VALUES ('4', 'Java高级开发工程师', 'Java高级开发工程师');
INSERT INTO `job_inf` VALUES ('5', '系统管理员', '系统管理员');
INSERT INTO `job_inf` VALUES ('6', '架构师', '架构师');
INSERT INTO `job_inf` VALUES ('7', '主管', '');
INSERT INTO `job_inf` VALUES ('8', '经理', '经理');
INSERT INTO `job_inf` VALUES ('9', '总经理', '总经理');
INSERT INTO `job_inf` VALUES ('10', '软件设计师', '软件设计师');
INSERT INTO `job_inf` VALUES ('11', '人力资源总监', '人力资源总监');
INSERT INTO `job_inf` VALUES ('12', '财务总监', '财务总监');
INSERT INTO `job_inf` VALUES ('13', '营销总监', '营销总监');
INSERT INTO `job_inf` VALUES ('14', '市场总监', '市场总监');
INSERT INTO `job_inf` VALUES ('15', '销售总监', '销售总监');
INSERT INTO `job_inf` VALUES ('16', '生产总监', '生产总监');
INSERT INTO `job_inf` VALUES ('17', '运营总监', '运营总监');
INSERT INTO `job_inf` VALUES ('18', '技术总监', '技术总监');
INSERT INTO `job_inf` VALUES ('20', '人力资源助理', '人力资源助理');
INSERT INTO `job_inf` VALUES ('21', '人力资源经理', '人力资源经理');
INSERT INTO `job_inf` VALUES ('22', '人力资源专员', '人力资源专员');
INSERT INTO `job_inf` VALUES ('23', '招聘主管', '招聘主管');
INSERT INTO `job_inf` VALUES ('24', '培训师', '培训师');
INSERT INTO `job_inf` VALUES ('25', '培训专员', '培训专员');
INSERT INTO `job_inf` VALUES ('26', '绩效考核主管', '绩效考核主管');
INSERT INTO `job_inf` VALUES ('27', '薪资福利主管', '薪资福利主管');
INSERT INTO `job_inf` VALUES ('28', '薪酬分析师', '薪酬分析师');
INSERT INTO `job_inf` VALUES ('29', '员工记录经理', '员工记录经理');
INSERT INTO `job_inf` VALUES ('30', '财务经理', '财务经理');
INSERT INTO `job_inf` VALUES ('31', '财务助理', '财务助理');
INSERT INTO `job_inf` VALUES ('32', '预算主管', '预算主管');
INSERT INTO `job_inf` VALUES ('33', '应收账款主管', '应收账款主管');
INSERT INTO `job_inf` VALUES ('34', '会计主管', '会计主管');
INSERT INTO `job_inf` VALUES ('35', '资金主管', '资金主管');
INSERT INTO `job_inf` VALUES ('36', '投资主管', '投资主管');
INSERT INTO `job_inf` VALUES ('37', '融资主管', '融资主管');
INSERT INTO `job_inf` VALUES ('38', '财务分析师', '财务分析师');
INSERT INTO `job_inf` VALUES ('39', '预算专员', '预算专员');
INSERT INTO `job_inf` VALUES ('40', '投资分析专员', '投资分析专员');
INSERT INTO `job_inf` VALUES ('41', '核算专员', '核算专员');
INSERT INTO `job_inf` VALUES ('42', '出纳员', '出纳员');
INSERT INTO `job_inf` VALUES ('43', '总经理秘书', '总经理秘书');
INSERT INTO `job_inf` VALUES ('44', '档案员', '档案员');
INSERT INTO `job_inf` VALUES ('45', '行政主管', '行政主管');
INSERT INTO `job_inf` VALUES ('46', '行政助理', '行政助理');
INSERT INTO `job_inf` VALUES ('47', '行政经理', '行政经理');
INSERT INTO `job_inf` VALUES ('48', '法律事务助理', '法律事务助理');
INSERT INTO `job_inf` VALUES ('49', '法律顾问', '法律顾问');
INSERT INTO `job_inf` VALUES ('50', '公司律师', '公司律师');
INSERT INTO `job_inf` VALUES ('51', '战略部主管', '战略部主管');
INSERT INTO `job_inf` VALUES ('52', '质检员', '质检员');
INSERT INTO `job_inf` VALUES ('53', '质量控制主管', '质量控制主管');
INSERT INTO `job_inf` VALUES ('54', '副总经理', '副总经理');
INSERT INTO `job_inf` VALUES ('55', '人力资源总监', '人力资源总监');
INSERT INTO `job_inf` VALUES ('56', '财务总监', '财务总监');
INSERT INTO `job_inf` VALUES ('57', '营销总监', '营销总监');
INSERT INTO `job_inf` VALUES ('58', '市场总监', '市场总监');
INSERT INTO `job_inf` VALUES ('59', '销售总监', '销售总监');
INSERT INTO `job_inf` VALUES ('60', '生产总监', '生产总监');
INSERT INTO `job_inf` VALUES ('61', '运营总监', '运营总监');
INSERT INTO `job_inf` VALUES ('62', '技术总监', '技术总监');
INSERT INTO `job_inf` VALUES ('63', '总经理助理', '总经理助理');
INSERT INTO `job_inf` VALUES ('64', '人力资源助理', '人力资源助理');
INSERT INTO `job_inf` VALUES ('65', '人力资源经理', '人力资源经理');
INSERT INTO `job_inf` VALUES ('66', '人力资源专员', '人力资源专员');
INSERT INTO `job_inf` VALUES ('67', '招聘主管', '招聘主管');
INSERT INTO `job_inf` VALUES ('68', '培训师', '培训师');
INSERT INTO `job_inf` VALUES ('69', '培训专员', '培训专员');
INSERT INTO `job_inf` VALUES ('70', '绩效考核主管', '绩效考核主管');
INSERT INTO `job_inf` VALUES ('71', '薪资福利主管', '薪资福利主管');
INSERT INTO `job_inf` VALUES ('72', '薪酬分析师', '薪酬分析师');
INSERT INTO `job_inf` VALUES ('73', '员工记录经理', '员工记录经理');
INSERT INTO `job_inf` VALUES ('74', '财务经理', '财务经理');
INSERT INTO `job_inf` VALUES ('75', '财务助理', '财务助理');
INSERT INTO `job_inf` VALUES ('76', '预算主管', '预算主管');
INSERT INTO `job_inf` VALUES ('77', '应收账款主管', '应收账款主管');
INSERT INTO `job_inf` VALUES ('78', '会计主管', '会计主管');
INSERT INTO `job_inf` VALUES ('79', '资金主管', '资金主管');
INSERT INTO `job_inf` VALUES ('80', '投资主管', '投资主管');
INSERT INTO `job_inf` VALUES ('81', '融资主管', '融资主管');
INSERT INTO `job_inf` VALUES ('82', '财务分析师', '财务分析师');
INSERT INTO `job_inf` VALUES ('83', '预算专员', '预算专员');
INSERT INTO `job_inf` VALUES ('84', '投资分析专员', '投资分析专员');
INSERT INTO `job_inf` VALUES ('85', '核算专员', '核算专员');
INSERT INTO `job_inf` VALUES ('86', '出纳员', '出纳员');
INSERT INTO `job_inf` VALUES ('87', '总经理秘书', '总经理秘书');
INSERT INTO `job_inf` VALUES ('88', '档案员', '档案员');
INSERT INTO `job_inf` VALUES ('89', '行政主管', '行政主管');
INSERT INTO `job_inf` VALUES ('90', '行政助理', '行政助理');
INSERT INTO `job_inf` VALUES ('91', '行政经理', '行政经理');
INSERT INTO `job_inf` VALUES ('92', '法律事务助理', '法律事务助理');
INSERT INTO `job_inf` VALUES ('93', '法律顾问', '法律顾问');
INSERT INTO `job_inf` VALUES ('94', '公司律师', '公司律师');
INSERT INTO `job_inf` VALUES ('95', '战略部主管', '战略部主管');
INSERT INTO `job_inf` VALUES ('96', '质检员', '质检员');
INSERT INTO `job_inf` VALUES ('97', '质量控制主管', '质量控制主管');
INSERT INTO `job_inf` VALUES ('98', '', '');
INSERT INTO `job_inf` VALUES ('99', '的沙发斯蒂芬', '的沙发斯蒂芬');
INSERT INTO `job_inf` VALUES ('100', 'FASDFSDAF', 'SDFASDFS');
INSERT INTO `job_inf` VALUES ('101', 'Appolo', '??');

-- ----------------------------
-- Table structure for notice_inf
-- ----------------------------
DROP TABLE IF EXISTS `notice_inf`;
CREATE TABLE `notice_inf` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id号',
  `title` varchar(50) NOT NULL COMMENT '职位名',
  `content` text NOT NULL COMMENT '备注',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建日期',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_NOTICE_USER` (`user_id`) USING BTREE,
  CONSTRAINT `FK_NOTICE_USER` FOREIGN KEY (`user_id`) REFERENCES `user_inf` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of notice_inf
-- ----------------------------
INSERT INTO `notice_inf` VALUES ('1', '系统管理员', '系统管理员', '2000-05-12 00:00:00', '1');
INSERT INTO `notice_inf` VALUES ('3', '架构师', '架构师', '1995-02-15 00:00:00', '2');
INSERT INTO `notice_inf` VALUES ('5', '经理', '经理', '1999-08-14 00:00:00', '2');
INSERT INTO `notice_inf` VALUES ('6', '总经理', '总经理', '1997-08-03 00:00:00', '1');
INSERT INTO `notice_inf` VALUES ('8', 'java高级开发工程师', 'java高级开发工程师', '1999-03-28 00:00:00', '2');
INSERT INTO `notice_inf` VALUES ('22', '多少朵话多或多或多或多或多或多多多多多v', '哒哒哒哒哒哒多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多多', '2020-06-18 10:57:35', null);
INSERT INTO `notice_inf` VALUES ('23', '大三度开发商考虑到话费卡红烧豆腐会啊', '好的覅胡迪发哈U盾上花覅史蒂夫hi阿萨德花覅u', '2020-06-18 10:58:16', null);

-- ----------------------------
-- Table structure for user_inf
-- ----------------------------
DROP TABLE IF EXISTS `user_inf`;
CREATE TABLE `user_inf` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id号',
  `loginname` varchar(20) NOT NULL COMMENT '账户名',
  `password` varchar(16) NOT NULL COMMENT '密码',
  `status` int(11) NOT NULL DEFAULT '2' COMMENT '用户状态',
  `createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `username` varchar(20) DEFAULT NULL COMMENT '用户名（超级管理员）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of user_inf
-- ----------------------------
INSERT INTO `user_inf` VALUES ('1', 'admin', '123456', '2', '2019-03-12 09:34:28', '超级管理员');
INSERT INTO `user_inf` VALUES ('2', 'root', '123456', '2', '2020-06-09 20:34:47', '超级管理员2');
INSERT INTO `user_inf` VALUES ('3', 'fgsdfgsdfgdsfg', 'dfgdfsgsdf', '1', '2020-06-17 17:10:00', 'gdfgsdfg');
INSERT INTO `user_inf` VALUES ('4', '阿粉红色的很深刻的发生的发生', '048484843', '1', '2020-06-17 20:28:32', '懂法守法水电费水电费');
INSERT INTO `user_inf` VALUES ('5', '发斯蒂芬斯蒂芬斯蒂芬', '049494933', '1', '2020-06-17 20:28:40', '手动阀是打发斯蒂芬');
INSERT INTO `user_inf` VALUES ('7', 'fdgdxfgdfgdf', '54645645', '1', '2020-06-17 22:04:02', 'dfdfgdfgdf');
INSERT INTO `user_inf` VALUES ('8', '分公司电饭锅电饭锅电饭锅', '的分隔森岛帆高森岛帆高水电费', '1', '2020-06-18 08:51:25', '浮动格式的分隔森岛帆高');
INSERT INTO `user_inf` VALUES ('9', '赛菲尔发', '123456', '1', '2020-06-19 00:00:00', '13423');
INSERT INTO `user_inf` VALUES ('10', '0411180311', '123456', '1', '2020-06-19 14:05:13', '暖气');
INSERT INTO `user_inf` VALUES ('11', '0411180305', '123456', '2', '2020-06-19 16:40:17', '洪得智');
INSERT INTO `user_inf` VALUES ('12', '0411180327', '123456', '1', '2020-06-19 16:45:12', '爱好');
INSERT INTO `user_inf` VALUES ('13', '666', '123456', '1', '2020-10-31 14:52:06', 'root');
